alert('Hello!');
const answer = prompt('What is your name?');
alert('Nice to meet you,' + answer + '!');