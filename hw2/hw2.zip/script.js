alert('Hello!');
const a = prompt('Enter the number 1, please:');
const b = prompt('Enter the number 2, please:');
const sum = Number(a) + Number(b);
const diff = a - b;
const mult = a * b;
const div = a / b;
alert(`Calculations are finished!
Sum: ${a}+${b}=${sum}
Diff: ${a}-${b}=${diff}
Mult: ${a}*${b}=${mult}
Div: ${a}/${b}=${div}`)